<?php

  echo "<table>";
  echo "<tr><th>Meta-Data</th><th>Value</th></tr>";

  # The URL root is the AWS meta-data service URL where metadata requests regarding the running instance can be made
  $urlRoot = "http://169.254.169.254/latest/meta-data/";
  $tokenUrl = "http://169.254.169.254/latest/api/token";

  # Define token request TTL (time to live) in seconds
  $tokenTtl = 21600;  # 6 hours (21600 seconds)

  # Fetch the token using IMDSv2
  $token = file_get_contents($tokenUrl, false, stream_context_create([
      'http' => [
          'method' => 'PUT',
          'header' => "X-aws-ec2-metadata-token-ttl-seconds: $tokenTtl"
      ]
  ]));

  if ($token) {
      # Prepare context to include the token in metadata requests
      $context = stream_context_create([
          'http' => [
              'header' => "X-aws-ec2-metadata-token: $token"
          ]
      ]);

      # Get the instance ID from meta-data and print to the screen
      $instanceId = file_get_contents($urlRoot . 'instance-id', false, $context);
      echo "<tr><td>InstanceId</td><td><i>" . htmlspecialchars($instanceId) . "</i></td></tr>";

      # Get the availability zone from meta-data and print to the screen
      $availabilityZone = file_get_contents($urlRoot . 'placement/availability-zone', false, $context);
      echo "<tr><td>Availability Zone</td><td><i>" . htmlspecialchars($availabilityZone) . "</i></td></tr>";
  } else {
      echo "<tr><td colspan='2'><i>Error: Unable to retrieve metadata token.</i></td></tr>";
  }

  echo "</table>";

?>