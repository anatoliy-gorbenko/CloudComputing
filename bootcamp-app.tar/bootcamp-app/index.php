<!DOCTYPE html>
<html>
  <head>
    <title>Welcome to the AWS Tech Fundamentals Bootcamp</title>
    <link href="style.css" media="all" rel="stylesheet" type="text/css" />
  </head>

  <body>
    <h1> Welcome to the Cloud Computing Development Module!</h1>
    <h1> This is your first AWS EC2 Linux Web Server</h1>

    <div id="wrapper">

      <?php include('menu.php'); ?>

      <?php include("get-index-meta-data.php"); ?>

      <hr />

      <?php include('get-cpu-load.php'); ?>
      <br>
      <p><em>Prof. Anatoliy Gorbenko, KhAI/LBU</em></p>

    </div>
  </body>
</html>
