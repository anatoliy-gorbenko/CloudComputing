<div id="header"><a href="/"><img src="https://upload.wikimedia.org/wikipedia/en/thumb/e/e1/Leeds_Beckett_University_-_New_logo.png/330px-Leeds_Beckett_University_-_New_logo.png" /></a></div>

<div id='menu'>
<ul>
  <li><a href="load.php">Load Test</a></li>
  <li><a href="rds.php">RDS</a></li>
</ul>
</div>
